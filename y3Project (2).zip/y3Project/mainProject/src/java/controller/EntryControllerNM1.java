/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Entry;
import model.User;

/**
 *
 * @author k00218290
 */
public class EntryControllerNM1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet EntryControllerNM1</title>");            
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>Servlet EntryControllerNM1 at " + request.getContextPath() + "</h1>");
//            out.println("</body>");
//            out.println("</html>");
//        }
    
            System.out.println("in entry controller");
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            user = new User();
            session.setAttribute("user", user);
        }
                
        String menu = "menu";
        Entry entry = (Entry) session.getAttribute("entry");
        if (entry == null) {
            entry = new Entry();
            session.setAttribute("entry", entry);
        }
        
        menu = request.getParameter("menu");
        if (menu == null) {
            menu = "Gallery";
        }
        System.out.println("menu " + menu);
        
    
        switch (menu) {
           case "Gallery":
           
             //  Entry entry = new Entry();
                ArrayList<Entry> allentries = new ArrayList<>();
                allentries = entry.getAllEntries();
                session.setAttribute("allentries", allentries);
                gotoPage("/GalleryNM.jsp", request, response);
                System.out.println("gallery");
                break;
            
        
          case "getEntryView":
           
             String entryId = request.getParameter("entryId");
              
                int entryid = Integer.parseInt(entryId);

                //call to ENTRY model to get entry details
                Entry e = new Entry();
                e = e.getEntryDetails(entryid);

               
            
                    
                    session.setAttribute("entry", e);

               
                
                gotoPage("/GalleryNM.jsp", request, response);
                break;
               default:
                gotoPage("/invalid.jsp", request, response);
                break; 
                
               case "img":
                   
    }

    }
  private void gotoPage(String url,
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher
                = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
