/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author k00218290
 */
public class User {
     private int userid;
    private String username;
    private String password;
    private String email;
    private String phone;
    private String course;

   

    public User() {
    }

    public User(String username, String password, String email, String phone, String course) {

        this.username = username;
        this.phone = phone;
        this.password = password;
        this.email = email;
        this.course = course;
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public User(int userid, String username, String password, String email, String phone, String course) {
        this.userid = userid;
        this.username = username;
        this.phone = phone;
        this.password = password;
        this.email = email;
        this.course = course;
    }
public User(int userid){
    this.userid=userid;
}
    
    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
