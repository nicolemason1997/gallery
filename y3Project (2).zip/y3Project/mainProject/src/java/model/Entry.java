/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author k00218290
 */
public class Entry {
    private int entryId;
    private int userId;
    private String entry;
    private String type;
    private String description;
    private double price;
    
    public void Entry(int entryId,int userId, String entry, String type, String description, double price){
    this.entryId=entryId;
    this.userId=userId;
    this.entry=entry;
    this.type=type;
    this.description=description;
    this.price=price;
    }
     public void Entry(int entryId, String entry){
         this.entryId=entryId;
         this.entry=entry;
     }    
    
    
    public int getEntryId() {
        return entryId;
    }

    public void setEntryId(int entryId) {
        this.entryId = entryId;
    }

    public String getEntry() {
        return entry;
    }

    public void setEntry(String entry) {
        this.entry = entry;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String descripton) {
        this.description = descripton;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
   
    public ArrayList<Entry> getAllEntries() {

        ArrayList allentries = new ArrayList<>();

        Connection connection = DatabaseUtilityClass.getConnection();
        PreparedStatement ps = null;
        ResultSet resultSet = null;

        String query = "Select * from entries";

        try {
            ps = connection.prepareStatement(query);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                Entry e = new Entry();
                e.setEntryId(resultSet.getInt("entry_id"));
                e.setEntry(resultSet.getString("entry"));
                e.setType(resultSet.getString("type"));
                e.setDescription(resultSet.getString("entry_description"));
                e.setPrice(resultSet.getDouble("price"));
                
                allentries.add(e);
            }

            connection.close();
            

        } catch (SQLException ex) {
            System.out.println(ex);
            return null;
        }
        

        return allentries;
    }
    public Entry getEntryDetails(int entryId) {
        
        Entry e = null;
        Connection connection = DatabaseUtilityClass.getConnection();
        PreparedStatement ps = null;
        ResultSet resultSet = null;

        String query = "Select * from entries where entry_id";

        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, entryId);

            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                e = new Entry();
                e.setEntryId(resultSet.getInt("entry_id"));
                e.setEntry(resultSet.getString("entry"));
                e.setType(resultSet.getString("type"));
                e.setDescription(resultSet.getString("entry_description"));
                e.setPrice(resultSet.getDouble("price"));
                return e;
            }

            connection.close();

        } catch (SQLException ex) {
            System.out.println(ex);
            return null;
        }

        return e;
    }
    public Entry displayFullDetails(int entryId, int userId){
        Entry e = null;
        Connection connection = DatabaseUtilityClass.getConnection();
        PreparedStatement ps = null;
        ResultSet resultSet = null;
        
        String query = "Select * from entries where entry_id";
        String query2 = "Select F_name, L_name where user_id"
    } 
}
